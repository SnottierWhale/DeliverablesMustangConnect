// Kelechi Igwe
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static org.junit.Assert.*;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Alert;
import org.openqa.selenium.Keys;
import java.util.*;
import java.net.MalformedURLException;
import java.net.URL;
public class Suite4Test {
  private WebDriver driver;
  private Map<String, Object> vars;
  JavascriptExecutor js;
  @Before
  public void setUp() {
    driver = new ChromeDriver();
    js = (JavascriptExecutor) driver;
    vars = new HashMap<String, Object>();
  }
  @After
  public void tearDown() {
    driver.quit();
  }
  @Test
  public void changeYourProfilePic() {
    driver.get("http://localhost:5000/");
    driver.manage().window().setSize(new Dimension(2196, 1196));
    driver.findElement(By.id("email")).click();
    driver.findElement(By.id("email")).sendKeys("jzmorris");
    driver.findElement(By.id("psswd")).click();
    driver.findElement(By.id("psswd")).sendKeys("1234");
    driver.findElement(By.id("psswd")).sendKeys(Keys.ENTER);
    driver.findElement(By.cssSelector("li:nth-child(6)")).click();
    driver.findElement(By.linkText("Profile")).click();
    driver.findElement(By.cssSelector(".changePic")).click();
    driver.findElement(By.id("file")).click();
    driver.findElement(By.id("file")).sendKeys("C:\\fakepath\\IMG_20200814_115417.jpg");
    driver.findElement(By.cssSelector(".btn")).click();
    driver.findElement(By.cssSelector("body")).click();
    driver.findElement(By.cssSelector("body")).click();
  }
  @Test
  public void checkIfUsersAreSuggested() {
    driver.get("http://localhost:5000/");
    driver.manage().window().setSize(new Dimension(2196, 1196));
    driver.findElement(By.id("email")).click();
    driver.findElement(By.id("email")).sendKeys("jdevkar");
    driver.findElement(By.id("psswd")).click();
    driver.findElement(By.id("psswd")).sendKeys("1234");
    driver.findElement(By.id("psswd")).sendKeys(Keys.ENTER);
    driver.findElement(By.linkText("Meet People!")).click();
    {
      List<WebElement> elements = driver.findElements(By.cssSelector(".container:nth-child(5) h2"));
      assert(elements.size() > 0);
    }
  }
}
